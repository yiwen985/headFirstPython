from setuptools import setup

setup(
    name='vsearch',
    # version='1.0',
    # description='The Head First Python Search Tools',
    # author='sss',
    # author_email='sss',
    # url='sss',
    py_modules=['vsearch'],
)